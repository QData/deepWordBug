The following command deletes a replication configuration from a bucket named ``my-bucket``::

  aws s3api delete-bucket-replication --bucket my-bucket
